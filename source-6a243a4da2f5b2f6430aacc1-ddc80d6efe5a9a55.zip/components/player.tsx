import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { StreamInfo } from "../App";
import { Tv, AlertCircle, Loader, Radio } from "lucide-react";
import { detectStreamType } from "../utils/streamutils";

declare global {
  interface Window {
    jwplayer: any;
    mpegts: any;
  }
}

interface PlayerProps {
  stream: StreamInfo | null;
}

export function Player({ stream }: PlayerProps) {
  const jwContainerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const jwInstance = useRef<any>(null);
  const mpegtsInstance = useRef<any>(null);
  const playerDivRef = useRef<HTMLDivElement | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [jwReady, setJwReady] = useState(false);
  const [playerId] = useState(`jw-player-${Math.random().toString(36).substring(2, 9)}`);

  const streamType = useMemo(() => (stream ? detectStreamType(stream.url) : null), [stream]);
  const isMpegTs = streamType?.type === "mpegts";

  // Load JWPlayer script once
  useEffect(() => {
    if (window.jwplayer) {
      window.jwplayer.key = "zTEbSn/eAplL0RLXT030FzOcek6qXmtrxju6Jg==";
      setJwReady(true);
      return;
    }
    const script = document.createElement("script");
    script.src = "https://ssl.p.jwpcdn.com/player/v/8.45.0/jwplayer.js";
    script.async = true;
    script.onload = () => {
      window.jwplayer.key = "zTEbSn/eAplL0RLXT030FzOcek6qXmtrxju6Jg==";
      setJwReady(true);
    };
    script.onerror = () => setError("Failed to load player library");
    document.body.appendChild(script);
  }, []);

  // Lazily load mpegts.js from CDN
  const loadMpegTsLib = useCallback((): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (window.mpegts) { resolve(); return; }
      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/npm/mpegts.js@latest/dist/mpegts.min.js";
      script.onload = () => resolve();
      script.onerror = () => reject(new Error("Failed to load mpegts.js"));
      document.head.appendChild(script);
    });
  }, []);

  const destroyJWPlayer = useCallback(() => {
    if (jwInstance.current) {
      try { jwInstance.current.remove(); } catch { /* ignore */ }
      jwInstance.current = null;
    }
    if (playerDivRef.current?.parentNode) {
      playerDivRef.current.parentNode.removeChild(playerDivRef.current);
      playerDivRef.current = null;
    }
  }, []);

  const destroyMpegTs = useCallback(() => {
    if (mpegtsInstance.current) {
      try {
        mpegtsInstance.current.unload();
        mpegtsInstance.current.detachMediaElement();
        mpegtsInstance.current.destroy();
      } catch { /* ignore */ }
      mpegtsInstance.current = null;
    }
  }, []);

  // MPEG-TS / IPTV Xtreme playback via mpegts.js
  useEffect(() => {
    if (!stream || !isMpegTs) return;

    setIsLoading(true);
    setError(null);
    destroyJWPlayer();
    destroyMpegTs();

    loadMpegTsLib()
      .then(() => {
        if (!window.mpegts?.isSupported()) {
          setError("MPEG-TS playback is not supported in this browser");
          setIsLoading(false);
          return;
        }

        const video = videoRef.current;
        if (!video) return;

        const player = window.mpegts.createPlayer(
          {
            type: "mpegts",
            url: stream.url,
            isLive: true,
            cors: true,
          },
          {
            enableWorker: true,
            enableStashBuffer: false,
            stashInitialSize: 128,
          }
        );

        player.attachMediaElement(video);
        player.load();

        player.on(window.mpegts.Events.ERROR, (_type: string, detail: string) => {
          console.error("mpegts error:", _type, detail);
          setError(`Stream error: ${detail || _type}`);
          setIsLoading(false);
        });

        video.play().then(() => setIsLoading(false)).catch((err: Error) => {
          // Autoplay blocked — user gesture required
          setIsLoading(false);
        });

        mpegtsInstance.current = player;
      })
      .catch((err: Error) => {
        setError(err.message);
        setIsLoading(false);
      });

    return () => { destroyMpegTs(); };
  }, [stream, isMpegTs, loadMpegTsLib, destroyMpegTs, destroyJWPlayer]);

  // HLS / DASH / unknown playback via JWPlayer
  useEffect(() => {
    if (!stream || isMpegTs || !jwReady || !jwContainerRef.current) return;

    setIsLoading(true);
    setError(null);
    destroyMpegTs();
    destroyJWPlayer();

    const playerDiv = document.createElement("div");
    playerDiv.id = playerId;
    playerDiv.style.cssText = "width:100%;height:100%;";
    jwContainerRef.current.appendChild(playerDiv);
    playerDivRef.current = playerDiv;

    const config: any = {
      file: stream.url,
      type: streamType?.type === "dash" ? "dash" : "hls",
      width: "100%",
      height: "100%",
      autostart: true,
      mute: false,
      primary: "html5",
      preload: "auto",
      aspectratio: "16:9",
      stretching: "uniform",
      playbackRateControls: true,
      playbackRates: [0.5, 1, 1.25, 1.5, 2],
      skin: {
        name: "seven",
        active: "#00d4ff",
        inactive: "#94a3b8",
        background: "#0f172a",
      },
    };

    if (stream.license && streamType?.type === "dash") {
      config.drm = { widevine: { url: stream.license } };
    }

    try {
      const jw = window.jwplayer(playerId);
      jw.setup(config);
      jwInstance.current = jw;

      jw.on("ready", () => setIsLoading(false));
      jw.on("play", () => setError(null));
      jw.on("error", (e: any) => {
        setError(`Playback error: ${e.message || "Unknown error"}`);
        setIsLoading(false);
      });
      jw.on("setupError", (e: any) => {
        setError(`Setup error: ${e.message || "Failed to initialize player"}`);
        setIsLoading(false);
      });
    } catch (err: any) {
      setError(err.message || "Failed to initialize player");
      setIsLoading(false);
    }

    return () => { destroyJWPlayer(); };
  }, [stream, isMpegTs, jwReady, playerId, streamType, destroyJWPlayer, destroyMpegTs]);

  if (!stream) {
    return (
      <div className="h-full flex items-center justify-center bg-slate-900 rounded-xl border border-slate-800">
        <div className="text-center">
          <div className="bg-slate-800 p-6 rounded-full inline-block mb-4">
            <Tv className="w-12 h-12 text-slate-600" />
          </div>
          <h3 className="text-slate-400 text-lg font-medium">No Stream Loaded</h3>
          <p className="text-slate-500 text-sm mt-2">
            Enter a stream URL above to start watching
          </p>
          <div className="mt-6 space-y-2">
            <p className="text-slate-600 text-xs">Supported formats:</p>
            <div className="flex justify-center gap-2 flex-wrap">
              <span className="px-2 py-1 rounded bg-slate-800 text-slate-400 text-xs">.m3u8 (HLS)</span>
              <span className="px-2 py-1 rounded bg-slate-800 text-slate-400 text-xs">.mpd (DASH)</span>
              <span className="px-2 py-1 rounded bg-slate-800 text-slate-400 text-xs">.ts (MPEG-TS)</span>
              <span className="px-2 py-1 rounded bg-amber-900/30 text-amber-400 text-xs border border-amber-800">
                IPTV Xtreme
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-full min-h-96 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-slate-900 flex items-center justify-center z-20">
          <div className="text-center">
            <Loader className="w-10 h-10 text-cyan-500 animate-spin mx-auto" />
            <p className="text-slate-400 mt-4">Loading stream...</p>
            {isMpegTs && (
              <p className="text-slate-500 text-xs mt-1">
                Connecting to {streamType?.isIPTVXtreme ? "IPTV Xtreme" : "MPEG-TS"} stream...
              </p>
            )}
          </div>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 bg-slate-900 flex items-center justify-center z-20">
          <div className="text-center max-w-md p-6">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
            <h3 className="text-white text-lg font-medium mt-4">Playback Error</h3>
            <p className="text-slate-400 text-sm mt-2">{error}</p>
            <p className="text-slate-500 text-xs mt-4">
              Please check the stream URL and try again
            </p>
          </div>
        </div>
      )}

      {/* IPTV Xtreme badge */}
      {!isLoading && !error && isMpegTs && streamType?.isIPTVXtreme && (
        <div className="absolute top-3 right-3 z-10 flex items-center gap-1 bg-amber-500/20 border border-amber-500/40 rounded px-2 py-1">
          <Radio className="w-3 h-3 text-amber-400" />
          <span className="text-amber-400 text-xs font-bold">LIVE</span>
        </div>
      )}

      {/* Native video element — used for MPEG-TS / IPTV Xtreme via mpegts.js */}
      <video
        ref={videoRef}
        className="w-full h-full"
        style={{
          display: isMpegTs ? "block" : "none",
          backgroundColor: "#000",
          minHeight: "400px",
        }}
        controls
        autoPlay
        playsInline
      />

      {/* JWPlayer mount point — used for HLS / DASH / unknown */}
      <div
        ref={jwContainerRef}
        className="w-full h-full"
        style={{
          display: isMpegTs ? "none" : "block",
          minHeight: "400px",
        }}
      />
    </div>
  );
}
