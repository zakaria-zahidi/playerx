import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Play, Link, Key } from "lucide-react";
import { StreamInfo } from "../App";

interface StreamInputProps {
  onPlay: (stream: StreamInfo) => void;
}

export function StreamInput({ onPlay }: StreamInputProps) {
  const [url, setUrl] = useState("");
  const [license, setLicense] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    
    onPlay({
      url: url.trim(),
      license: license.trim() || undefined,
    });
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
    } catch {
      // Clipboard access denied
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-900 rounded-xl p-4 border border-slate-800">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="stream-url" className="text-slate-300 flex items-center gap-2">
            <Link className="w-4 h-4" />
            Stream URL
          </Label>
          <div className="flex gap-2">
            <Input
              id="stream-url"
              type="url"
              placeholder="https://example.com/stream.m3u8  or  http://host:port/user/pass/id"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
            />
            <Button
              type="button"
              variant="outline"
              onClick={handlePaste}
              className="shrink-0 border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              Paste
            </Button>
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="license-key" className="text-slate-300 flex items-center gap-2">
            <Key className="w-4 h-4" />
            License URL (Optional)
          </Label>
          <Input
            id="license-key"
            type="url"
            placeholder="DRM license URL for protected streams"
            value={license}
            onChange={(e) => setLicense(e.target.value)}
            className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
          />
        </div>
      </div>
      
      <div className="flex items-center justify-between mt-4">
        <div className="flex gap-2 flex-wrap">
          <span className="px-2 py-1 rounded bg-emerald-500 text-white text-xs font-bold">HLS</span>
          <span className="px-2 py-1 rounded bg-purple-500 text-white text-xs font-bold">DASH</span>
          <span className="px-2 py-1 rounded bg-amber-500 text-white text-xs font-bold">MPEG-TS</span>
          <span className="px-2 py-1 rounded bg-orange-700 text-white text-xs font-bold">IPTV Xtreme</span>
        </div>
        
        <Button
          type="submit"
          disabled={!url.trim()}
          className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold px-6"
        >
          <Play className="w-4 h-4 mr-2" />
          Play Stream
        </Button>
      </div>
    </form>
  );
}