import { Clock, Play } from "lucide-react";
import { StreamInfo } from "../App";

interface SidebarProps {
  recentStreams: StreamInfo[];
  onSelectStream: (stream: StreamInfo) => void;
}

export function Sidebar({ recentStreams, onSelectStream }: SidebarProps) {
  const getStreamName = (url: string) => {
    try {
      const urlObj = new URL(url);
      const pathParts = urlObj.pathname.split("/");
      const filename = pathParts[pathParts.length - 1];
      return filename || urlObj.hostname;
    } catch {
      return url.substring(0, 30) + "...";
    }
  };

  const getStreamType = (url: string) => {
    if (url.includes(".mpd") || url.includes("dash")) return "DASH";
    if (url.includes(".m3u8") || url.includes("m3u8")) return "HLS";
    if (url.includes(".ts")) return "MPEG-TS";

    // Detect IPTV Xtreme / XtreamCodes patterns
    const urlLower = url.toLowerCase();
    if (/\/live\/[^/?#]+\/[^/?#]+\/\d+/.test(urlLower)) return "IPTV";
    if (/\/movie\/[^/?#]+\/[^/?#]+\/\d+/.test(urlLower)) return "IPTV";
    try {
      const p = new URL(url);
      if (p.port && /^\/[^/?#]+\/[^/?#]+\/\d+$/.test(p.pathname)) return "IPTV";
    } catch { /* ignore */ }

    return "LIVE";
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "DASH": return "bg-purple-500";
      case "MPEG-TS": return "bg-amber-500";
      case "HLS": return "bg-emerald-500";
      case "IPTV": return "bg-orange-700";
      default: return "bg-cyan-500";
    }
  };

  return (
    <aside className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col">
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center gap-2 text-slate-400">
          <Clock className="w-4 h-4" />
          <span className="text-sm font-medium">Recent Streams</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto p-2">
        {recentStreams.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <p className="text-sm">No recent streams</p>
            <p className="text-xs mt-1">Enter a URL to start watching</p>
          </div>
        ) : (
          <div className="space-y-1">
            {recentStreams.map((stream, index) => {
              const type = getStreamType(stream.url);
              return (
                <button
                  key={index}
                  onClick={() => onSelectStream(stream)}
                  className="w-full p-3 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors text-left group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">
                        {getStreamName(stream.url)}
                      </p>
                      <p className="text-slate-500 text-xs mt-1 truncate">
                        {stream.url.substring(0, 40)}...
                      </p>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-xs font-bold text-white ${getTypeColor(type)}`}>
                      {type}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 mt-2 text-slate-500">
                    <Play className="w-3 h-3" />
                    <span className="text-xs">Click to play</span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
      
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded-lg p-3">
          <p className="text-slate-400 text-xs">
            Supported formats: HLS, DASH, MPEG-TS, IPTV Xtreme
          </p>
          <p className="text-slate-500 text-xs mt-1">
            Works with IPTV Xtreme links
          </p>
        </div>
      </div>
    </aside>
  );
}