import { useState, useEffect } from "react";
import { Player } from "./components/Player";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { StreamInput } from "./components/StreamInput";

export interface StreamInfo {
  url: string;
  license?: string;
  name?: string;
}

export default function App() {
  const [currentStream, setCurrentStream] = useState<StreamInfo | null>(null);
  const [recentStreams, setRecentStreams] = useState<StreamInfo[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    // Check URL hash for stream
    const hash = window.location.hash.substring(1);
    if (hash) {
      let url = hash;
      let license: string | undefined;
      
      if (hash.includes("license=")) {
        const parts = hash.split("license=");
        url = parts[0].replace(/[?&]$/, "");
        license = parts[1];
      }
      
      try {
        url = decodeURIComponent(url);
        if (license) license = decodeURIComponent(license);
      } catch {
        // URL already decoded
      }
      
      setCurrentStream({ url, license });
    }
    
    // Load recent streams from localStorage
    const saved = localStorage.getItem("recentStreams");
    if (saved) {
      try {
        setRecentStreams(JSON.parse(saved));
      } catch {
        // Invalid data
      }
    }
  }, []);

  const handlePlayStream = (stream: StreamInfo) => {
    setCurrentStream(stream);
    window.location.hash = stream.url + (stream.license ? `?license=${stream.license}` : "");
    
    // Add to recent streams
    const updated = [stream, ...recentStreams.filter(s => s.url !== stream.url)].slice(0, 10);
    setRecentStreams(updated);
    localStorage.setItem("recentStreams", JSON.stringify(updated));
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      <Header 
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
      />
      
      <div className="flex flex-1 overflow-hidden">
        {isSidebarOpen && (
          <Sidebar 
            recentStreams={recentStreams}
            onSelectStream={handlePlayStream}
          />
        )}
        
        <main className="flex-1 flex flex-col p-4 overflow-auto">
          <StreamInput onPlay={handlePlayStream} />
          
          <div className="flex-1 mt-4 min-h-96">
            <Player stream={currentStream} />
          </div>
        </main>
      </div>
    </div>
  );
}