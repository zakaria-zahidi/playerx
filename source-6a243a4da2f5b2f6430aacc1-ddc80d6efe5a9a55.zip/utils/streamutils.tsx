export interface StreamType {
  type: "hls" | "dash" | "mpegts" | "unknown";
  extension: string;
  needsLicense: boolean;
  isIPTVXtreme: boolean;
}

// Detects XtreamCodes/IPTV Xtreme URL patterns:
//   /live/user/pass/id[.ts]
//   /movie/user/pass/id
//   host:port/user/pass/id  (numeric stream ID with no extension)
function isIPTVXtremeUrl(url: string): boolean {
  const urlLower = url.toLowerCase();

  if (/\/live\/[^/?#]+\/[^/?#]+\/\d+/.test(urlLower)) return true;
  if (/\/movie\/[^/?#]+\/[^/?#]+\/\d+/.test(urlLower)) return true;
  if (/\/series\/[^/?#]+\/[^/?#]+\/\d+/.test(urlLower)) return true;

  try {
    const parsed = new URL(url);
    // XtreamCodes API-style: non-standard port + /user/pass/id path
    if (parsed.port && /^\/[^/?#]+\/[^/?#]+\/\d+$/.test(parsed.pathname)) {
      return true;
    }
  } catch {
    // invalid URL
  }

  return false;
}

export function detectStreamType(url: string): StreamType {
  const urlLower = url.toLowerCase();

  if (urlLower.includes(".mpd") || urlLower.includes("manifest.mpd")) {
    return {
      type: "dash",
      extension: ".mpd",
      needsLicense: urlLower.includes("drm") || urlLower.includes("protected"),
      isIPTVXtreme: false,
    };
  }

  if (urlLower.includes(".m3u8") || urlLower.includes("m3u8")) {
    return {
      type: "hls",
      extension: ".m3u8",
      needsLicense: false,
      isIPTVXtreme: false,
    };
  }

  const hasTsExtension = /\.ts(\?|$)/.test(urlLower);
  const isIPTV = isIPTVXtremeUrl(url);

  if (hasTsExtension || isIPTV) {
    return {
      type: "mpegts",
      extension: ".ts",
      needsLicense: false,
      isIPTVXtreme: isIPTV,
    };
  }

  return {
    type: "unknown",
    extension: "",
    needsLicense: false,
    isIPTVXtreme: false,
  };
}

export function formatStreamUrl(url: string): string {
  let formatted = url.trim();
  if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
    formatted = "https://" + formatted;
  }
  return formatted;
}

export function validateStreamUrl(url: string): { valid: boolean; error?: string } {
  if (!url) return { valid: false, error: "URL is required" };

  try {
    const parsed = new URL(url);
    if (!parsed.hostname) return { valid: false, error: "Invalid hostname" };
    return { valid: true };
  } catch {
    return { valid: false, error: "Invalid URL format" };
  }
}

export function getStreamName(url: string): string {
  try {
    const parsed = new URL(url);
    const pathParts = parsed.pathname.split("/");
    const filename = pathParts[pathParts.length - 1];
    const name = filename.replace(/\.[^/.]+$/, "");
    return name || parsed.hostname;
  } catch {
    return "Unknown Stream";
  }
}
